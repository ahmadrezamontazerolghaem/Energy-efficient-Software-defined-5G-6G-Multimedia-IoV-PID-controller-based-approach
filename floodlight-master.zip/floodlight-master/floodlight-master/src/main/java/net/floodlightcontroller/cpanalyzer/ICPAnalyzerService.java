package net.floodlightcontroller.cpanalyzer;

import net.floodlightcontroller.core.module.IFloodlightService;

public interface ICPAnalyzerService extends IFloodlightService {

}
