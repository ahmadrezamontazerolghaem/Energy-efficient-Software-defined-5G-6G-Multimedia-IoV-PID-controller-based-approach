package net.floodlightcontroller.packet.gtp;

public class GTPUPacket extends AbstractGTP {
	
	public GTPUPacket(){
		super();
		this.setControlPacket(false);
	}

}
